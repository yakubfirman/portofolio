"""
app.py — Flask REST API untuk portfolio Yakub Firman Mustofa.
Dijalankan di PythonAnywhere sebagai web app.
"""

import json
import os
import re
import sqlite3

from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)

# ─── CORS: ganti dengan domain Vercel kamu ───────────────────────────────────
_raw_origins = os.environ.get(
    "ALLOWED_ORIGINS",
    "https://yakubfirman.id",
)
ALLOWED_ORIGINS = [o.strip() for o in _raw_origins.split(",")]
CORS(app, origins=ALLOWED_ORIGINS)

DB_PATH = os.path.join(os.path.dirname(__file__), "portfolio.db")

SLUG_RE = re.compile(r"^[a-z0-9-]+$")


# ─── Helpers ─────────────────────────────────────────────────────────────────

def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _build_project(conn: sqlite3.Connection, row: sqlite3.Row) -> dict:
    details = conn.execute(
        "SELECT role, overview FROM project_details WHERE project_id = ?",
        (row["id"],),
    ).fetchone()
    contributions = conn.execute(
        "SELECT contribution FROM project_contributions WHERE project_id = ? ORDER BY sort_order",
        (row["id"],),
    ).fetchall()
    return {
        "name": row["name"],
        "slug": row["slug"],
        "description": row["description"],
        "tech": json.loads(row["tech"]),
        "url": row["url"],
        "image": row["image"],
        "details": {
            "role": details["role"] if details else "",
            "overview": details["overview"] if details else "",
            "contributions": [c["contribution"] for c in contributions],
        },
    }


# ─── Routes ──────────────────────────────────────────────────────────────────

@app.route("/api/projects", methods=["GET"])
def get_projects():
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM projects ORDER BY sort_order"
        ).fetchall()
        return jsonify([_build_project(conn, r) for r in rows])
    finally:
        conn.close()


@app.route("/api/projects/<slug>", methods=["GET"])
def get_project(slug: str):
    # Validasi slug — hanya huruf kecil, angka, dan tanda hubung
    if not SLUG_RE.match(slug):
        return jsonify({"error": "Invalid slug"}), 400

    conn = get_db()
    try:
        row = conn.execute(
            "SELECT * FROM projects WHERE slug = ?", (slug,)
        ).fetchone()
        if not row:
            return jsonify({"error": "Not found"}), 404
        return jsonify(_build_project(conn, row))
    finally:
        conn.close()


@app.route("/api/speaking", methods=["GET"])
def get_speaking():
    conn = get_db()
    try:
        rows = conn.execute(
            "SELECT * FROM speaking_events ORDER BY sort_order"
        ).fetchall()
        return jsonify([
            {
                "title": r["title"],
                "event": r["event"],
                "organizer": r["organizer"],
                "date": r["date"],
                "location": r["location"],
                "topics": json.loads(r["topics"]),
                "url": r["url"],
                "audience": r["audience"],
            }
            for r in rows
        ])
    finally:
        conn.close()


@app.route("/api/about", methods=["GET"])
def get_about():
    conn = get_db()
    try:
        meta = conn.execute("SELECT icon_key, text FROM about_meta ORDER BY sort_order").fetchall()
        education = conn.execute(
            "SELECT icon_key, degree, school, year, note FROM about_education ORDER BY sort_order"
        ).fetchall()
        highlights = conn.execute(
            "SELECT value, label FROM about_highlights ORDER BY sort_order"
        ).fetchall()
        focus_tags = conn.execute(
            "SELECT tag FROM about_focus_tags ORDER BY sort_order"
        ).fetchall()
        return jsonify({
            "meta": [{"icon_key": m["icon_key"], "text": m["text"]} for m in meta],
            "education": [
                {
                    "icon_key": e["icon_key"],
                    "degree": e["degree"],
                    "school": e["school"],
                    "year": e["year"],
                    "note": e["note"],
                }
                for e in education
            ],
            "highlights": [{"value": h["value"], "label": h["label"]} for h in highlights],
            "focus_tags": [f["tag"] for f in focus_tags],
        })
    finally:
        conn.close()


@app.route("/api/skills", methods=["GET"])
def get_skills():
    conn = get_db()
    try:
        categories = conn.execute(
            "SELECT * FROM skill_categories ORDER BY sort_order"
        ).fetchall()
        result = []
        for cat in categories:
            items = conn.execute(
                "SELECT name, pct FROM skill_category_items WHERE category_id = ? ORDER BY sort_order",
                (cat["id"],),
            ).fetchall()
            result.append({
                "label": cat["label"],
                "icon_key": cat["icon_key"],
                "icon_bg": cat["icon_bg"],
                "skills": [{"name": i["name"], "pct": i["pct"]} for i in items],
            })
        return jsonify({"categories": result})
    finally:
        conn.close()


@app.route("/api/socials", methods=["GET"])
def get_socials():
    conn = get_db()
    try:
        rows = conn.execute("SELECT label, href, icon_key FROM socials ORDER BY sort_order").fetchall()
        return jsonify([
            {"label": r["label"], "href": r["href"], "icon_key": r["icon_key"]}
            for r in rows
        ])
    finally:
        conn.close()


# ─── Entry point (development only) ─────────────────────────────────────────

if __name__ == "__main__":
    app.run(debug=False)
